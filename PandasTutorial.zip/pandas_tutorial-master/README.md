# PANDAS_TUTORIAL

###About

This is an introductory pandas tutorial. All the code in the notebooks was tested on version 0.22.0.
The aim is to learn pandas through exploring Botswana's 2014 general elections dataset.
The tutorial has  in depth  coverage of Pandas applied to the dataset.All the fundamental 
principles are applied with example code.

Happy Learning
